package PAF15.appointmentPAF;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.*;

import com.mysql.cj.xdevapi.PreparableStatement;

public class AppointmentRepository {

	Connection con = null;
	
	List<Appointment> appointments;
	public AppointmentRepository() {
		
		String url ="jdbc:mysql://localhost:3606/";
		String username = "root";
		String password ="";
		try {
			
			Class.forName("com.mysql.jbdc.Driver");
			con = DriverManager.getConnection(url,username,password);
		
		
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			
		}
		
		
		appointments = new ArrayList<Appointment>();
		
		Appointment d1 = new Appointment();
				
				
		d1.setName("Amila");
		d1.setId(001);
		d1.setNIC("942524695v");
		d1.setTime("10.30pm");
		
		 
		Appointment d2 = new Appointment();
		d2.setName("Gihan");
		d2.setId(012);
		d2.setNIC("942226695v");
		d2.setTime("12.30pm");
		
		
		Appointment d3 = new Appointment();
		d3.setName("Supun");
		d3.setId(013);
		d3.setNIC("943528695v");
		d3.setTime("08.30pm");
		
		appointments.add(d1);
		appointments.add(d2);
		appointments.add(d3);
		
		
		
	}
	
	public List<Appointment>getAllappointments(){
		
		return appointments;
		
	}
	
	public Appointment createAppointment(Appointment d1) {
		String insertSql = "INSERT INTO `appointment`(`id`, `name`, `NIC`, `Time`) VALUES ([value-1],[value-2],[value-3],[value-4])";
		
		try {
			PreparedStatement st = con.prepareStatement(insertSql);
			st.setInt(1, d1.id);
			st.setString(2, d1.name);
			st.setString(3, d1.NIC);
			st.setString(4, d1.Time);
			
			
			st.executeUpdate();
			
		}catch (Exception e) {
			System.out.println(e);
			
			
		}
		
		appointments.add(d1);
		System.out.println(d1);
		return d1;
		
	}
	
}






