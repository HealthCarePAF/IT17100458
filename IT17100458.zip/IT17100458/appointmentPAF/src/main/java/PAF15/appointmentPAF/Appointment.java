package PAF15.appointmentPAF;

public class Appointment {

	public String name;
	public String NIC;
	public int id;
	public String Time;
	
	
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNIC() {
		return NIC;
	}
	@Override
	public String toString() {
		return "Appointment [name=" + name + ", NIC=" + NIC + ", id=" + id + "]";
	}
	public void setNIC(String nIC) {
		NIC = nIC;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
}
