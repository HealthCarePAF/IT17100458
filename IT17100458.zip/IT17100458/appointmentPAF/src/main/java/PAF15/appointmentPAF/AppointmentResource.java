package PAF15.appointmentPAF;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/appointments")

public class AppointmentResource {
	
	AppointmentRepository sr = new AppointmentRepository();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Appointment> getAllAppointment() {

			return sr.getAllappointments();
		
	}
	
	@POST
	@Path("/appointment")
	@Consumes(MediaType.APPLICATION_JSON)
	public Appointment createAppointment(Appointment d1) {
		
		
	return sr.createAppointment(d1);
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
